<div align="center">

<h1> 🐍 Cobralingo 🐍 </h1>

<img width="80%" src="https://github.com/Cam1ss/Projeto_Apple_Academy/assets/125037138/25492536-7b89-4607-a8c0-b29a59c15966">

<a href="https://github.com/Cam1ss" target="_self" rel="external">Camila Braúna</a> 
  • <a href="https://github.com/frsmth" target="_self" rel="external">Antônio Abner</a> •
    <a href="https://github.com/TheAnders007" target="_self" rel="external">Anderson Maia</a> • 
    <a href="https://github.com/mareshbard" target="_self" rel="external">Letícia Vitória</a>

</div>

<div align="left">

<h2> 📍 :: Descrição </h2>
   
- Disciplina: Prática Profissional II
- Professor: José Roberto

<h2> 📷 :: Imagens do Projeto </h2>

- Em Breve

<h2> 💻 :: Ferramentas Utilizadas </h2>

<div align="center">

[![SkillIcons](https://skillicons.dev/icons?i=js,html,css,figma)](https://skillicons.dev)<br/>

</div>

![Static Badge](https://img.shields.io/badge/STATUS-EM%20ANDAMENTO-brightgreen?style=for-the-badge&color=yellow)

